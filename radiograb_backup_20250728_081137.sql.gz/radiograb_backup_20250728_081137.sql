-- MySQL dump 10.13  Distrib 8.0.42, for Linux (x86_64)
--
-- Host: localhost    Database: radiograb
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cron_jobs`
--

DROP TABLE IF EXISTS `cron_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cron_jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `show_id` int NOT NULL,
  `cron_expression` varchar(100) NOT NULL,
  `command` text NOT NULL,
  `status` varchar(50) DEFAULT 'active',
  `last_run` timestamp NULL DEFAULT NULL,
  `next_run` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_show_id` (`show_id`),
  KEY `idx_status` (`status`),
  KEY `idx_next_run` (`next_run`),
  CONSTRAINT `cron_jobs_ibfk_1` FOREIGN KEY (`show_id`) REFERENCES `shows` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cron_jobs`
--

LOCK TABLES `cron_jobs` WRITE;
/*!40000 ALTER TABLE `cron_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `cron_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordings`
--

DROP TABLE IF EXISTS `recordings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recordings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `show_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `duration_seconds` int DEFAULT NULL,
  `file_size_bytes` bigint DEFAULT NULL,
  `recorded_at` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_show_id` (`show_id`),
  KEY `idx_recorded_at` (`recorded_at`),
  KEY `idx_filename` (`filename`),
  CONSTRAINT `recordings_ibfk_1` FOREIGN KEY (`show_id`) REFERENCES `shows` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordings`
--

LOCK TABLES `recordings` WRITE;
/*!40000 ALTER TABLE `recordings` DISABLE KEYS */;
INSERT INTO `recordings` VALUES (20,50,'WEHC_WombatsandMusic_20250727_1400.mp3','Wombats and Music - 2025-07-27 14:00','Automated recording of Wombats and Music from WEHC 90.7 FM',3600,57664000,'2025-07-27 18:00:00','2025-07-27 19:00:00'),(24,74,'WERU_on-demand_2025-07-28-005210.mp3','WERU On-Demand Recording - 2025-07-28 00:52','On-demand recording started at 2025-07-28 00:52:10',3600,0,'2025-07-28 04:52:10','2025-07-28 04:52:10');
/*!40000 ALTER TABLE `recordings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `migration_name` varchar(255) NOT NULL,
  `executed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `migration_name` (`migration_name`),
  KEY `idx_migration_name` (`migration_name`),
  KEY `idx_executed_at` (`executed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES (1,'add_stream_testing_fields','2025-07-22 10:37:05');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shows`
--

DROP TABLE IF EXISTS `shows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `station_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  `host` varchar(255) DEFAULT NULL,
  `schedule_pattern` varchar(255) NOT NULL COMMENT 'Cron-like pattern',
  `schedule_description` varchar(500) DEFAULT NULL COMMENT 'Human readable schedule',
  `retention_days` int DEFAULT '30',
  `audio_format` varchar(10) DEFAULT 'mp3',
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `duration_minutes` int DEFAULT '60',
  `genre` varchar(100) DEFAULT NULL,
  `auto_imported` tinyint(1) DEFAULT '0',
  `timezone` varchar(50) DEFAULT 'America/New_York',
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `days` varchar(255) DEFAULT NULL,
  `tags` text COMMENT 'Comma-separated tags for show categorization',
  PRIMARY KEY (`id`),
  KEY `idx_station_id` (`station_id`),
  KEY `idx_active` (`active`),
  KEY `idx_name` (`name`),
  KEY `idx_active_shows` (`active`),
  CONSTRAINT `shows_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `stations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shows`
--

LOCK TABLES `shows` WRITE;
/*!40000 ALTER TABLE `shows` DISABLE KEYS */;
INSERT INTO `shows` VALUES (2,3,'Acadia Highway','Host: Sister Moxie, Sam Spruce | Genre: Acadian, Cajun, Zydeco','Sister Moxie, Sam Spruce','0 11 * * 0','Sundays at 11:00',30,'mp3',1,'2025-07-20 07:58:35','2025-07-28 06:17:18',120,'Acadian, Cajun, Zydeco',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(10,3,'Woodstock Nation','Host: The Bick | Genre: Classic Rock','The Bick','0 13 * * 0','Sundays at 13:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',120,'Classic Rock',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(11,3,'Folk Music with Cousin Phil','Host: Cousin Phil | Genre: Folk','Cousin Phil','0 10 * * 1','Mondays at 10:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',120,'Folk',1,'America/New_York',NULL,NULL,NULL,'folk,acoustic'),(12,3,'Midnight One Radio','Host: L.WILLIE-OH | Genre: Rock','L.WILLIE-OH','0 0 * * 0','Sundays at 00:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',120,'Rock',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(16,3,'Saturday Morning Coffeehouse','Host: Matthew Baya, Chuck Markowitz, Cheryl | Genre: Folk','Matthew Baya, Chuck Markowitz, Cheryl','0 8 * * 6','Saturdays at 08:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',120,'Folk',1,'America/New_York',NULL,NULL,NULL,'morning,coffeehouse'),(17,3,'Sunday Morning Coffeehouse','Host: Ned Johnston, Reverend Redbeard, Kristen | Genre: Folk','Ned Johnston, Reverend Redbeard, Kristen','0 8 * * 0','Sundays at 08:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',120,'Folk',1,'America/New_York',NULL,NULL,NULL,'morning,coffeehouse'),(20,3,'New Potatoes','Host: Matt & Maureen, Kathleen Rybarz | Genre: Celtic','Matt & Maureen, Kathleen Rybarz','0 10 * * 0','Sundays at 10:00',30,'mp3',1,'2025-07-20 07:58:36','2025-07-28 06:17:18',60,'Celtic',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(35,1,'Infinite Highway','Host: WEHC DJ | Genre: Alternative','WEHC DJ','0 20 * * 1','Mondays at 20:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Alternative',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(36,1,'Appalachian Vibes','Host: WEHC DJ | Genre: Appalachian','WEHC DJ','0 14 * * 5','Fridays at 14:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Appalachian',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(40,1,'Hobo Stew','Host: WEHC DJ | Genre: Variety','WEHC DJ','0 21 * * 5','Fridays at 21:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Variety',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(46,1,'Born in the Mountain','Host: WEHC Live | Genre: Mountain Music','WEHC Live','0 13 * * 4','Thursdays at 13:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Mountain Music',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(50,1,'Wombats and Music','Host: WEHC DJ | Genre: Eclectic','WEHC DJ','0 14 * * 6','Saturdays at 14:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Eclectic',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(53,1,'Bluegrass Time!','Host: WEHC DJ | Genre: Bluegrass','WEHC DJ','0 14 * * 0','Sundays at 14:00',30,'mp3',1,'2025-07-20 12:57:06','2025-07-28 06:17:18',60,'Bluegrass',1,'America/New_York',NULL,NULL,NULL,'bluegrass,traditional'),(56,4,'The M&M Show','Host: WTBR DJ | Genre: Community Radio','WTBR DJ','0 10 * * 2','Tuesdays at 10:00',30,'mp3',1,'2025-07-20 20:39:46','2025-07-28 06:17:18',30,'Community Radio',1,'America/New_York',NULL,NULL,NULL,'music,variety'),(68,5,'The Dear Green Place','WYSO program: The Dear Green Place','','0 13 * * 0','Sundays at 1:00 PM to 3:00 PM',30,'mp3',1,'2025-07-22 02:14:49','2025-07-28 11:58:07',60,NULL,0,'America/New_York',NULL,NULL,NULL,'music,variety'),(69,5,'Down Home Bluegrass','WYSO program: Down Home Bluegrass','','0 18 * * 6','Saturdays at 6:00 PM to 8:00 PM',30,'mp3',1,'2025-07-22 02:14:49','2025-07-28 11:58:12',60,NULL,0,'America/New_York',NULL,NULL,NULL,'bluegrass,traditional'),(70,5,'Rise When the Rooster Crows','WYSO program: Rise When the Rooster Crows','','0 6 * * 0','Sundays at 6:00 AM to 8:00 AM',30,'mp3',1,'2025-07-22 02:14:49','2025-07-28 11:58:16',60,NULL,0,'America/New_York',NULL,NULL,NULL,'music,variety'),(71,4,'The Blade','Radio program: The Blade','','0 12 * * 1','Record every Monday at 12:00 PM to 12:30 PM',30,'mp3',1,'2025-07-23 06:01:49','2025-07-28 06:17:18',60,NULL,0,'America/New_York',NULL,NULL,NULL,'music,variety'),(72,5,'WYSO On-Demand Recordings','On-demand recordings from WYSO',NULL,'','Manual on-demand recordings',30,'mp3',1,'2025-07-23 16:25:04','2025-07-23 16:25:04',60,NULL,0,'America/New_York',NULL,NULL,NULL,NULL),(73,1,'WEHC On-Demand Recordings','On-demand recordings from WEHC 90.7 FM',NULL,'','Manual on-demand recordings',30,'mp3',1,'2025-07-25 20:11:59','2025-07-25 20:11:59',60,NULL,0,'America/New_York',NULL,NULL,NULL,NULL),(74,3,'WERU On-Demand Recordings','On-demand recordings from WERU',NULL,'','Manual on-demand recordings',30,'mp3',1,'2025-07-28 04:52:10','2025-07-28 04:52:10',60,NULL,0,'America/New_York',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `shows` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stations`
--

DROP TABLE IF EXISTS `stations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `call_letters` varchar(10) DEFAULT NULL,
  `website_url` varchar(500) NOT NULL,
  `stream_url` varchar(500) DEFAULT NULL,
  `logo_url` varchar(500) DEFAULT NULL,
  `description` text,
  `calendar_url` varchar(500) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `calendar_parsing_method` text,
  `recommended_recording_tool` varchar(50) DEFAULT NULL COMMENT 'Best tool for recording this stream (streamripper, ffmpeg, wget)',
  `stream_compatibility` varchar(20) DEFAULT 'unknown' COMMENT 'Stream compatibility status (compatible, incompatible, unknown)',
  `stream_test_results` text COMMENT 'JSON data with detailed stream test results',
  `last_stream_test` timestamp NULL DEFAULT NULL COMMENT 'When stream was last tested',
  `user_agent` varchar(500) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT 'America/New_York',
  `last_tested` datetime DEFAULT NULL,
  `last_test_result` enum('success','failed','error') DEFAULT NULL,
  `last_test_error` text,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_status` (`status`),
  KEY `idx_stream_compatibility` (`stream_compatibility`),
  KEY `idx_recommended_tool` (`recommended_recording_tool`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stations`
--

LOCK TABLES `stations` WRITE;
/*!40000 ALTER TABLE `stations` DISABLE KEYS */;
INSERT INTO `stations` VALUES (1,'WEHC 90.7 FM','WEHC','https://www.emoryhenry.edu/wehc/','https://wehc.streamguys1.com/live',NULL,NULL,NULL,'active','2025-07-19 23:20:19','2025-07-27 19:00:01',NULL,'streamripper','compatible',NULL,NULL,NULL,'America/New_York','2025-07-27 15:00:01','success',NULL),(3,'WERU','WERU','https://weru.org','http://pacificaservice.org:8000/weru_128','https://weru.org/wp-content/uploads/2019/10/logo-cropped-square.png','Community radio from Maine',NULL,'active','2025-07-19 23:58:57','2025-07-28 12:00:00',NULL,NULL,'unknown','{\"source\": \"radio_browser\", \"confidence\": 1.0, \"discovery_date\": \"2025-07-27 01:32:48\", \"old_url\": \"https://stream.pacificaservice.org:9000/weru_128\", \"radio_browser_name\": \"WERU Community Radio\", \"bitrate\": 128, \"codec\": \"MP3\"}',NULL,NULL,'America/New_York','2025-07-28 08:00:00','failed','[Errno 2] No such file or directory: \'streamripper\''),(4,'WTBR - 89.7 FM - Pittsfield Public Schools, WT','WTBR','https://wtbrfm.com','http://us3.streamingpulse.com:7224/stream','https://wtbrfm.com/wp-content/uploads/elementor/thumbs/STATIC-Rural-Intelligence-Readers-Choice-Logo-1-pyj1zxa3pof2jnh2u635fxsvt5qqpzssol2mvzl17g.png',NULL,NULL,'active','2025-07-20 15:14:16','2025-07-28 00:23:27',NULL,NULL,'unknown','{\"source\": \"radio_browser_frequency\", \"confidence\": 1.0, \"discovery_date\": \"2025-07-27 08:20:59\", \"old_url\": \"https://streams.radiomast.io/15c0b63b-cfaf-4cdf-9e46-4b14c3a56b01\", \"radio_browser_name\": \"WVGV Radio 89.7 FM - West Virginia Gospel Voice\", \"bitrate\": 96, \"codec\": \"MP3\"}',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36','America/New_York','2025-07-27 20:23:28','success',NULL),(5,'WYSO','WYSO','https://www.wyso.org','https://26253.live.streamtheworld.com:443/WYSOHD2.mp3','https://npr.brightspotcdn.com/dims4/default/790af44/2147483647/strip/true/crop/2616x738+0+0/resize/267x75!/quality/90/?url=http%3A%2F%2Fnpr-brightspot.s3.amazonaws.com%2F9b%2F40%2Fbc00a28241f09f80d672924a0d87%2Fwyso-new-logo-final-cmyk-2023.png',NULL,'https://www.wyso.org/all-shows','active','2025-07-20 20:40:47','2025-07-28 12:10:31','custom_wyso','wget','compatible',NULL,NULL,NULL,'America/New_York','2025-07-28 08:10:32','error','Schedule parsing error: \'ScheduleParser\' object has no attribute \'parse_station_schedule\''),(6,'KULT','KULT','https://online.radio.moe/public/radiokult','https://online.radio.moe/listen/radiokult/radio.mp3','https://online.radio.moe/static/icons/production/192.png',NULL,'https://online.radio.moe/public/radiokult','active','2025-07-25 18:23:25','2025-07-28 12:10:31',NULL,NULL,'unknown',NULL,NULL,NULL,'America/New_York','2025-07-28 08:10:32','error','Schedule parsing error: \'ScheduleParser\' object has no attribute \'parse_station_schedule\'');
/*!40000 ALTER TABLE `stations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_tests`
--

DROP TABLE IF EXISTS `stream_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_tests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `station_id` int NOT NULL,
  `stream_url` varchar(500) NOT NULL,
  `test_results` text NOT NULL COMMENT 'JSON results from stream test',
  `recommended_tool` varchar(50) DEFAULT NULL,
  `compatibility_status` varchar(20) NOT NULL,
  `test_duration_seconds` decimal(5,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_station_id` (`station_id`),
  KEY `idx_compatibility` (`compatibility_status`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `stream_tests_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `stations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_tests`
--

LOCK TABLES `stream_tests` WRITE;
/*!40000 ALTER TABLE `stream_tests` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_tests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-28  8:11:39
